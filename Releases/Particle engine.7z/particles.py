### EXESOFT PARTICLE ENGINE
# Copyright David Barker 2010
#
# Particle and ParticleSource objects


import keyframes, random, math, pygame


class Particle:
	def __init__(self, initpos, velocity, drawtype = 0, colour = (0, 0, 0), radius = 0.0, length = 0.0, image = None, keyframes = []):
		self.pos = initpos
		self.velocity = velocity
		self.colour = colour
		self.radius = radius
		self.length = length
		self.image = image
		self.drawtype = drawtype
		
		self.keyframes = keyframes
		self.CreateKeyframe(0, self.colour, self.radius, self.length)
		self.curframe = 0
	
	def Update(self):
		self.pos = [self.pos[0] + self.velocity[0], self.pos[1] + self.velocity[1]]
		
		self.curframe = self.curframe + 1
	
	def Draw(self, display):
		if self.drawtype == 0:  # Point
			pygame.draw.circle(display, self.colour, self.pos, 0)
			
		elif self.drawtype == 1:  # Circle
			pygame.draw.circle(display, self.colour, self.pos, self.radius)
			
		elif self.drawtype == 2:  # Line
			endpoint = [self.pos[0] + self.velocity[0], self.pos[1] + self.velocity[1]]
			pygame.draw.aaline(display, self.colour, self.pos, endpoint)
			
		elif self.drawtype == 3:  # Image
			pass  # Will do this later :P

	def CreateKeyframe(self, frame, colour, radius, length):
		newframe = keyframes.ParticleKeyframe(frame, colour, radius, length)
		self.keyframes.append(newframe)


class ParticleSource:
	def __init__(self, parenteffect, pos, initspeed, initdirection, initspeedrandrange, initdirectionrandrange, particlesperframe, drawtype = 0, colour = (0, 0, 0), radius = 0.0, length = 0.0, image = None):
		self.parenteffect = parenteffect
		self.pos = pos
		self.initspeed = initspeed
		self.initdirection = initdirection
		self.initspeedrandrange = initspeedrandrange
		self.initdirectionrandrange = initdirectionrandrange
		self.particlesperframe = particlesperframe
		self.colour = colour
		self.drawtype = drawtype
		self.radius = radius
		self.length = length
		self.image = image

		self.keyframes = []
		self.CreateKeyframe(0, self.pos, self.initspeed, self.initdirection, self.initspeedrandrange, self.initdirectionrandrange, self.particlesperframe)
		
		self.particlekeyframes = []
		self.CreateParticleKeyframe(0, self.colour, self.radius, self.length)
		self.curframe = 0
	
	def Update(self):
		particlesperframe = self.particlesperframe
		for i in range(0, particlesperframe):
			self.CreateParticle()
		
		self.curframe = self.curframe + 1
	
	def CreateParticle(self):
		if self.initspeedrandrange != 0.0:
			speed = self.initspeed + (float(random.randrange(-self.initspeedrandrange * 100.0, self.initspeedrandrange * 100.0)) / 100.0)
		else:
			speed = self.initspeed
		if self.initdirectionrandrange != 0.0:
			direction = self.initdirection + (float(random.randrange(-self.initdirectionrandrange * 100.0, self.initdirectionrandrange * 100.0)) / 100.0)
		else:
			direction = self.initdirection
		velocity = [speed * math.sin(direction), -speed * math.cos(direction)]
		newparticle = Particle(initpos = self.pos, velocity = velocity, drawtype = self.drawtype, colour = self.colour, radius = self.radius, length = self.length, image = self.image, keyframes = self.particlekeyframes)
		self.parenteffect.AddParticle(newparticle)

	def CreateKeyframe(self, frame, pos, initspeed, initdirection, initspeedrandrange, initdirectionrandrange, particlesperframe):
		newframe = keyframes.SourceKeyframe(frame, pos, initspeed, initdirection, initspeedrandrange, initdirectionrandrange, particlesperframe)
		self.keyframes.append(newframe)
	
	def CreateParticleKeyframe(self, frame, colour, radius, length):
		newframe = keyframes.ParticleKeyframe(frame, colour, radius, length)
		self.particlekeyframes.append(newframe)
