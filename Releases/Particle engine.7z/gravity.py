### EXESOFT PARTICLE ENGINE ###
# Copyright David Barker 2010
#
# Gravity objects

from math import sqrt
import keyframes

UNIVERSAL_CONSTANT_OF_MAKE_GRAVITY_LESS_STUPIDLY_SMALL = 1000.0  # Well, Newton got one to make it less stupidly large.


class DirectedGravity:
	def __init__(self, strength = 0.0, direction = [0, 1]):
		self.strength = strength
		directionmag = sqrt(direction[0]**2 + direction[1]**2)
		self.direction = [direction[0] / directionmag, direction[1] / directionmag]
		
		self.keyframes = []
		self.CreateKeyframe(0, self.strength, self.direction)
		self.curframe = 0
	
	def Update(self):
		# Do stuff
		
		self.curframe = self.curframe + 1
	
	def GetForce(self, pos):
		force = [self.strength * self.direction[0], self.strength * self.direction[1]]
		
		return force
	
	def CreateKeyframe(self, frame, strength, direction):
		newframe = keyframes.PointGravityKeyframe(frame, strength, direction)
		self.keyframes.append(newframe)


class PointGravity:
	def __init__(self, strength = 0.0, pos = (0, 0)):
		self.strength = strength
		self.pos = pos
		
		self.keyframes = []
		self.CreateKeyframe(0, self.strength, self.pos)
		self.curframe = 0
	
	def Update(self):
		# Do stuff
		
		self.curframe = self.curframe + 1
	
	def GetForce(self, pos):
		if pos == self.pos:
			return [0.0, 0.0]
		
		distsquared = (pow(float(pos[0] - self.pos[0]), 2.0) + pow(float(pos[1] - self.pos[1]), 2.0))
		forcemag = (self.strength * UNIVERSAL_CONSTANT_OF_MAKE_GRAVITY_LESS_STUPIDLY_SMALL) / (distsquared)
		
		# Calculate normal vector from pos to the gravity point and multiply by force magnitude to find force vector
		dist = sqrt(distsquared)
		dx = float(self.pos[0] - pos[0]) / dist
		dy = float(self.pos[1] - pos[1]) / dist
		
		force = [forcemag * dx, forcemag * dy]
		
		return force
	
	def GetMaxForce(self):
		return self.strength * UNIVERSAL_CONSTANT_OF_MAKE_GRAVITY_LESS_STUPIDLY_SMALL
	
	def CreateKeyframe(self, frame, strength, pos):
		newframe = keyframes.DirectedGravityKeyframe(frame, strength, pos)
		self.keyframes.append(newframe)
