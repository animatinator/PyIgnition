### EXESOFT PYIGNITION ###
# Copyright David Barker 2010
#
# Keyframe object and generic keyframe creation function


def CreateKeyframe(parentframes, frame, variables):
	newframe = Keyframe(frame, variables)
	
	if frame != 0:  # If the frame is greater than zero, erase duplicate keyframes
		for duplicate in (keyframe for keyframe in parentframes if keyframe.frame == frame):
			parentframes.remove(duplicate)
		
	else:  # Otherwise, make sure all variables are defined - use values from the previous frame zero keyframe where variables aren't defined
		try:
			oldkey = (keyframe for keyframe in parentframes if keyframe.frame == 0).next()
		except StopIteration:  # A keyframe for frame zero has not been defined, so this must be the __init__ function's call
			oldkey = None  # In which case it's safe to assume that all variables are defined (unless I forgot something...)
		
		if oldkey:
			for var in oldkey.variables.keys():  # For every variable defined by the old keyframe
				if var not in newframe.variables:  # If a variable is undefined, copy its value to the new keyframe
					newframe.variables[var] = oldkey.variables[var]
	
	# Append the new keyframe then sort them all by frame
	parentframes.append(newframe)
	sortedframes = sorted(parentframes, key=lambda keyframe: keyframe.frame)
	parentframes[:] = sortedframes

class Keyframe:
	def __init__(self, frame = 0, variables = {}):
		self.frame = frame
		self.variables = variables
		
		if not ('interpolationtype' in self.variables):
			self.variables['interpolationtype'] = "linear"
			